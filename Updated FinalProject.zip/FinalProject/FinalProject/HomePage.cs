﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class HomePage : Form
    {
        private string connectionString = @"Data Source=LAB109PC21\\SQLEXPRESS;Initial Catalog=RailwaySistema;Integrated Security=True";

        public string UserID { get; set; }
        public HomePage(string userid)
        {
            InitializeComponent();
            UserID = userid;
        }

        private void HomePage_Load(object sender, EventArgs e)
        {
            label1.Text = "User: " + UserID;
            LoadDataIntoDataGridView();
        }

        private void LoadDataIntoDataGridView()
        {
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(@"Data Source=LAB109PC21\SQLEXPRESS; Initial Catalog=RailwaySistema; Integrated Security=True;"))
                {

                    sqlCon.Open(); // Open SQL connection

                    // Start with a base SQL query
                    string query = "SELECT * FROM Price WHERE availability='free'";
                    SqlCommand cmd = new SqlCommand(query, sqlCon);


                    // Use SqlDataAdapter to fetch data and populate DataGridView
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataSet ds = new DataSet();
                        adapter.Fill(ds);
                        dataGridView1.DataSource = ds.Tables.Count > 0 ? ds.Tables[0] : null;
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Extract data from the selected row
                int ticketid = Convert.ToInt32(row.Cells["TicketID"].Value);
                string price = row.Cells["Price"].Value.ToString();
                string desFrom = row.Cells["DesFrom"].Value.ToString();
                string desTo = row.Cells["DesTo"].Value.ToString();
                string date = row.Cells["Date"].Value.ToString();

                // Create a new instance of the DetailsForm and pass data to it
                BuyForm detailsForm = new BuyForm(ticketid, UserID, price, desFrom, desTo, date);
                detailsForm.ShowDialog(); // Show the form as a modal dialog
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadDataIntoDataGridView();
        }
    }
}
