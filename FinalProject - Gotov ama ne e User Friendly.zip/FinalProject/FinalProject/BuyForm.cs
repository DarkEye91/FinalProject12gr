﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class BuyForm : Form
    {
        public int TicketID { get; set; }
        public string UserID { get; set; }
        public string Price { get; set; }
        public string DesFrom { get; set; }
        public string DesTo { get; set; }
        public string Date { get; set; }

        public BuyForm(int ticketid, string userID, string price, string desFrom, string desTo, string date)
        {
            InitializeComponent();
            TicketID = ticketid;
            UserID = userID;
            Price = price;
            DesFrom = desFrom;
            DesTo = desTo;
            Date = date;
        }

        private void BuyForm_Load(object sender, EventArgs e)
        {
            textBox1.Text = Price;
            textBox2.Text = DesFrom;
            textBox3.Text = Date;
            textBox4.Text = DesTo;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=LAB109PC21\\SQLEXPRESS;Initial Catalog=RailwaySistema;Integrated Security=True";

            string query = "INSERT INTO Auth (UserID, TicketID) VALUES (@UserID, @TicketID)";
            string updateQuery = "UPDATE Price SET availability = 'not free' WHERE TicketID = @TicketID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        command.Parameters.AddWithValue("@TicketID", TicketID);
                        command.Parameters.AddWithValue("@UserID", UserID);
                        updateCommand.Parameters.AddWithValue("@TicketID", TicketID);

                        command.ExecuteNonQuery();
                        updateCommand.ExecuteNonQuery();

                        MessageBox.Show("Successful payment!", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                }
            }
        }
    }
}
