﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class HomePage : Form
    {
        private string connectionString = @"Data Source=LAB109PC21\\SQLEXPRESS;Initial Catalog=RailwaySistema;Integrated Security=True";

        public string UserID { get; set; }

        public HomePage(string userid)
        {
            InitializeComponent();
            UserID = userid;
        }

        private void HomePage_Load(object sender, EventArgs e)
        {
            label1.Text = "User: " + UserID;
            LoadDataIntoDataGridView();
        }

        private void LoadDataIntoDataGridView()
        {
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(@"Data Source=LAB109PC21\SQLEXPRESS; Initial Catalog=RailwaySistema; Integrated Security=True;"))
                {
                    sqlCon.Open();
                    string query = "SELECT * FROM Price WHERE availability='free'";
                    SqlCommand cmd = new SqlCommand(query, sqlCon);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataSet ds = new DataSet();
                        adapter.Fill(ds);
                        dataGridView1.DataSource = ds.Tables.Count > 0 ? ds.Tables[0] : null;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                int ticketid = Convert.ToInt32(row.Cells["TicketID"].Value);
                string price = row.Cells["Price"].Value.ToString();
                string desFrom = row.Cells["DesFrom"].Value.ToString();
                string desTo = row.Cells["DesTo"].Value.ToString();
                string date = row.Cells["Date"].Value.ToString();

                BuyForm detailsForm = new BuyForm(ticketid, UserID, price, desFrom, desTo, date);
                detailsForm.ShowDialog();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadDataIntoDataGridView();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Preview previewForm = new Preview(UserID);
            previewForm.Show();
            this.Close();
        }
    }
}
