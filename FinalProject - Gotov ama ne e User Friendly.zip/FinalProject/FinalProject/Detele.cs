﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Detele : Form
    {
        public int TicketID { get; set; }
        public string UserID { get; set; }
        public string Price { get; set; }
        public string DesFrom { get; set; }
        public string DesTo { get; set; }
        public string Date { get; set; }

        public Detele(int ticketid, string userID, string price, string desFrom, string desTo, string date)
        {
            InitializeComponent();
            TicketID = ticketid;
            UserID = userID;
            Price = price;
            DesFrom = desFrom;
            DesTo = desTo;
            Date = date;
        }

        private void Detele_Load(object sender, EventArgs e)
        {
            label1.Text = $"Ticket number: {TicketID}";
            textBox1.Text = Price;
            textBox2.Text = DesFrom;
            textBox3.Text = Date;
            textBox4.Text = DesTo;
        }

        private void DeleteEntry(int ticketID)
        {
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=LAB109PC21\SQLEXPRESS; Initial Catalog=RailwaySistema; Integrated Security=True;"))
            {
                sqlCon.Open();
                string query = "DELETE FROM Auth WHERE TicketID = @TicketID";
                string updateQuery = "UPDATE Price SET availability = 'free' WHERE TicketID = @TicketID";

                using (SqlCommand cmd = new SqlCommand(query, sqlCon))
                {
                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, sqlCon))
                    {
                        cmd.Parameters.AddWithValue("@TicketID", ticketID);
                        updateCmd.Parameters.AddWithValue("@TicketID", ticketID);

                        cmd.ExecuteNonQuery();
                        updateCmd.ExecuteNonQuery();
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to delete the selected entry?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    DeleteEntry(TicketID);
                    MessageBox.Show("Successful Deletion!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting entry: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
