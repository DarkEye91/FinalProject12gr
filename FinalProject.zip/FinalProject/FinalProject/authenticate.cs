﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    internal class authenticate
    {
        public class User
        {
            public string UserID { get; set; }
            public string Username { get; set; }
            public string Passoword { get; set; }
            public string Email { get; set; }
            public string Phone { get; set; }
            public DateTime Birthday { get; set; }

        }

        public class DatabaseManager
        {
            public static User AuthenticateUser(string username, string password, string email = "", string gender = "")
            {
                User user = RetrieveUserInformation(username, password, email, gender);
                return user;
            }
            private static User RetrieveUserInformation(string username, string password, string email, string gender)
            {
                using (SqlConnection sqlCon = new SqlConnection(@"Data Source=LAB109PC01\SQLEXPRESS; Initial Catalog=DataBaza; Integrated Security=True;"))
                {
                    sqlCon.Open();

                    string loginQuery = "SELECT COUNT(1) FROM userInfo WHERE Username=@Username AND Password=@Password";
                    string imgQuery = "SELECT img FROM userInfo WHERE Username=@Username AND Password=@Password";

                    using (SqlCommand loginCmd = new SqlCommand(loginQuery, sqlCon))
                    {
                        using (SqlCommand imgCmd = new SqlCommand(imgQuery, sqlCon))
                        {
                            loginCmd.CommandType = CommandType.Text;
                            imgCmd.CommandType = CommandType.Text;

                            loginCmd.Parameters.AddWithValue("@Username", username);
                            loginCmd.Parameters.AddWithValue("@Password", password);
                            imgCmd.Parameters.AddWithValue("@Username", username);
                            imgCmd.Parameters.AddWithValue("@Password", password);

                            int count = Convert.ToInt32(loginCmd.ExecuteScalar());

                            if (count == 1)
                            {
                                using (SqlDataReader reader = imgCmd.ExecuteReader())
                                {
                                    if (reader.Read())
                                    {
                                        byte[] imageData = reader["img"] as byte[];
                                        return new User { Username = username, Image = imageData, Email = email, Gender = gender };
                                    }
                                }
                            }

                            return null; // Return null if no user is found with the specified username and password
                        }
                    }
                }
            }





        }
    }
}
