﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static FinalProject.authenticate;

namespace FinalProject
{
    public partial class LogIN : Form
    {
        public LogIN()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user = textBox1.Text;
            string pass = textBox2.Text;
            string email = LogMailE.Text;
            string gender = GenderBoxi.Text;

            if (!string.IsNullOrWhiteSpace(user) && !string.IsNullOrWhiteSpace(pass) && !string.IsNullOrWhiteSpace(email))
            {
                User authenticatedUser = DatabaseManager.AuthenticateUser(user, email, pass, gender);

                if (authenticatedUser != null)
                {
                    HomePage welcome = new HomePage(authenticatedUser);
                    welcome.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid username or password or email.");
                }
            }
            else
            {
                MessageBox.Show("Please enter username and password and email.");
            }
        }
    }
}
